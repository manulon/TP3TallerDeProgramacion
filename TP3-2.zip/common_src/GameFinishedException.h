#ifndef GAME_FINISHED_EXCEPTION_H
#define GAME_FINISHED_EXCEPTION_H

#include <exception>

class GameFinishedException : public std::exception {};

#endif
