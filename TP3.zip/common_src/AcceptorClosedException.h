#ifndef ACCEPTOR_CLOSED_EXCEPTION_H
#define ACCEPTOR_CLOSED_EXCEPTION_H

#include <exception>

class AcceptorClosedException : public std::exception {};

#endif
